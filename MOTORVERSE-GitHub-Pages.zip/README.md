# MOTORVERSE

Site statique compatible GitHub Pages.

## Publication
1. Créer un dépôt GitHub.
2. Ajouter `index.html` et `.nojekyll`.
3. Aller dans Settings → Pages.
4. Choisir la branche contenant les fichiers comme source.
5. Ouvrir l'adresse `https://TON-PSEUDO.github.io/NOM-DU-DEPOT/`.

GitHub Pages sert les sites `github.io` en HTTPS.
